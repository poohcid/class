# ITF - Web Fundamentals

## Folder structure
* static-webpage

Faculty of Information Technology @ King Mongkut's Institute of Technology Ladkrabang