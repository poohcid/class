var CheckFood=0;
var CountFood=[0, 0, 0, 0, 0, 0, 0, 0];
setInterval(function(){
    var x = 0;
    var add=1;
    var typeBox = Math.floor(Math.random()*8 + 1);
    x = document.getElementById("b"+typeBox).innerHTML;
    x = Number(x);
    var In = Number(typeBox-1);
    document.getElementById("score").innerHTML = typeBox+","+In;
    if (CountFood[In] > 0){
      add = 4;
      CountFood[In]--;
    }
    if (x != 0){
        x += add;
        document.getElementById("b"+typeBox).innerHTML = x;
    }
    document.getElementById("bord").innerHTML = CountFood;
}, 300);

function change(id){
  var check = document.getElementById(id).innerHTML;
  var num = document.getElementById(id);
  var x = id[1];
  if (check == 0){
    num.innerHTML = 1;
    num.style.backgroundColor = "red";
  }
  if (CheckFood == 1){
      CheckFood = 0;
      CountFood[x-1] += 5;
      alert(CountFood);
    }
}

function food(){
  CheckFood = 1;
  alert(CheckFood);
}