<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Jabont_Simple
 */

?>
<div class="footer">
    <div class="logo">
        <img src="http://161.246.38.35/~it61070166/wordpress/wp-content/uploads/2019/05/it.png" alt="">
    </div>
    <div class="text">
        <h3>เว็บนี้เป็นส่วนของโปรเจควิชา Multimedia Technology KMITL</h3>
    </div>
<?php wp_footer(); ?>

</body>
</html>
