<?php /* Template Name: News */ ?>
<?php get_header() ?>
 this is page news 
<?php get_footer() ?>