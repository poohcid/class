<?php /* Template Name: Home */ ?>
<!DOCTYPE html>
<html>
<head>
	<?php wp_head() ?>
</head>
<body>


<?php wp_footer() ?>
</body>
</html>